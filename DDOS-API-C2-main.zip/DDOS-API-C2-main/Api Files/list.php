<?php
 
// 𝐓𝐡𝐞𝐬𝐞 𝐚𝐫𝐞 𝐭𝐡𝐞 𝐛𝐥𝐚𝐜𝐤𝐥𝐢𝐬𝐭𝐞𝐝 𝐥𝐢𝐬𝐭 𝐨𝐟 𝐈𝐏'𝐬!

$blacklisted = array(
 "1.1.1.1",
 "8.8.8.8",
 "https://usa.gov",
 "https://fbi.gov",
 "https://nasa.gov",
 "http://guiltyapi.xyz",
 "google.com");