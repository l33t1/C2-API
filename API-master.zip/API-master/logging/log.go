package logging

import (
	"fmt"
	"time"
)

func Log(message string) {
	println("[" + time.Now().Format("2006-01-02 15:04:05") + "] [\033[32mInfo\u001B[0m] " + message + "\u001b[0m")
}

func LogError(message string, err ...error) {
	if err != nil {
		println("[" + time.Now().Format("2006-01-02 15:04:05") + "] [\033[31mERROR\u001B[0m] \u001b[31;1m" + message + "\u001B[0m\r\nError: ")
		fmt.Println(err)
	} else {
		println("[" + time.Now().Format("2006-01-02 15:04:05") + "] [\033[31mERROR\u001B[0m] \u001b[31;1m" + message + "\u001B[0m")
	}
}

func LogWarning(message string) {
	println("[" + time.Now().Format("2006-01-02 15:04:05") + "] [\033[33mWARNING\u001B[0m] \u001b[33;1m" + message + "\u001B[0m")
}
