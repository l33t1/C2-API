package raw

import (
	"fmt"
	"main.go/database"
	"strings"
)

var blockedIPs map[string]bool

func CheckDuplicate(ip string) bool {
	if blockedIPs[ip] {
		return true
	}

	for _, bot := range database.QBots {
		if strings.Split(bot.RemoteAddr().String(), ":")[0] == ip && !database.Config.QBot.Dupes {
			fmt.Println("[BLOCKED] Blocked Bot Connection")
			blockedIPs[ip] = true
			return true
		}
	}

	for _, bot := range database.Mirai {
		if strings.Split(bot.RemoteAddr().String(), ":")[0] == ip && !database.Config.Mirai.Dupes {
			fmt.Println("[BLOCKED] Blocked Bot Connection")
			blockedIPs[ip] = true
			return true
		}
	}

	return false
}
