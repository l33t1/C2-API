package assets

type Server struct {
	Name     string `json:"Name"`
	Host     string `json:"Host"`
	Username string `json:"Username"`
	Password string `json:"Password"`
	Command  string `json:"Command"`
}

type Methods struct {
	Methods []Method `json:"Methods"`
}

type Method struct {
	Name        string   `json:"Name"`
	Time        int      `json:"Time"`
	API         []string `json:"API"`
	Permissions []string `json:"Permissions"`
	Server      []Server `json:"Server"`
	QBOT        struct {
		Command string `json:"Command"`
		Bots    int    `json:"Bots"`
	} `json:"QBOT"`
	MIRAI struct {
		PortFlag   int `json:"PortFlag"`
		MethodFlag int `json:"MethodFlag"`
		LenFlag    int `json:"LenFlag"`
		Bots       int `json:"Bots"`
	} `json:"MIRAI"`
}

type User struct {
	ID          int    `json:"ID"`
	Name        string `json:"Name"`
	Key         string `json:"key"`
	Role        string `json:"Role"`
	MaxTime     int    `json:"MaxTime"`
	Concurrent  int    `json:"Concurrent"`
	Cooldown    int    `json:"Cooldown"`
	HasCooldown bool   `json:"HasCooldown"`
	Banned      int    `json:"Banned"`
	Expiry      string `json:"Expiry"`
}

type Settings struct {
	Host    string `json:"Host"`
	Enabled int    `json:"Enabled"`
}

type Config struct {
	MaxCons     int      `json:"MaxCons"`
	TimeLimit   int      `json:"TimeLimit"`
	Discord     []string `json:"Discord"`
	Telegram    []string `json:"Telegram"`
	Bot         string   `json:"Bot"`
	Prefix      string   `json:"Prefix"`
	Screen      bool     `json:"Screen"`
	Blacklist   []string `json:"Blacklist"`
	Whitelist   []string `json:"Whitelist"`
	Powersaving bool     `json:"Powersaving"`
	QBot        struct {
		Host  string `json:"Host"`
		Port  int    `json:"Port"`
		Dupes bool   `json:"Dupes"`
	}

	Mirai struct {
		Host  string `json:"Host"`
		Port  int    `json:"Port"`
		Dupes bool   `json:"Dupes"`
	}
}

type Concurrent struct {
	User    User
	Targets []string
	Con     int
}
