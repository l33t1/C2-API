const fs = require("fs");

function attack_logs(log) {
  fs.appendFile('./assets/attacks.log', log + '\n', function (err) {
    if (err) throw err;
  });
}
exports.attack_logs = attack_logs;
