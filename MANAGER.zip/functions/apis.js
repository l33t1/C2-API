const { parseJsonFile } = require('./parseJsonFile');
const config = parseJsonFile('./assets/json_files/config.json');
const apis = parseJsonFile('./assets/json_files/methods.json');
const axios = require('axios');

function sendAPI(host, port, time, method) {
  const formattedDate = new Date().toISOString();
  
  apis[method].api.forEach(api => {
    const url = api.replace('<<$host>>', host).replace('<<$port>>', port).replace('<<$time>>', time);

    axios.get(url)
      .then(response => {
        if (response.status === 200) {

        } else {

        }
      })
      .catch(error => {
        if (error.response && error.response.status) {

        } else {

        }
      });
  });
}

exports.sendAPI = sendAPI;
