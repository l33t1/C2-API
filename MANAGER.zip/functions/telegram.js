const axios = require('axios');


async function sendTelegramWebhook(botToken, chatId, message) {
    const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
    const payload = {
      chat_id: chatId,
      text: message
    };
  
    try {
     await axios.post(url, payload);
    } catch (error) {
    }
  }
  
  exports.sendTelegramWebhook = sendTelegramWebhook;
